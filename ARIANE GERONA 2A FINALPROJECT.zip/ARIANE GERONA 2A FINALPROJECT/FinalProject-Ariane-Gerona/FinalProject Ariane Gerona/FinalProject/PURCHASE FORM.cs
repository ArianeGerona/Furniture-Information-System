﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalProject
{
    public partial class PURCHASE_FORM : Form
    {
        public PURCHASE_FORM()
        {
            InitializeComponent();
        }

        private void PURCHASE_FORM_Load(object sender, EventArgs e)
        {
            InfoDB.getMax();
            lblId.Text = InfoStorage.infoSet.furnitureId.ToString();
        }

        private void btnPurback_Click(object sender, EventArgs e)
        {
           CHAIR form= new CHAIR();
            this.Hide();
            form.Show();
        }

        private void btnOrder_Click(object sender, EventArgs e)
        {
            InfoDB.saveUpdateDeleteData("INSERT INTO `customer_info`(`Customer ID`, `Name`, `Address`, `Phone Number`) VALUES ('"+InfoStorage.infoSet.maxId+"','"+tbxName.Text+"','"+tbxAddress.Text+"','"+tbxPhoneNumber.Text+"')", "Saved");
            InfoDB.saveUpdateDeleteData("INSERT INTO `order_detail`( ` Customer ID`, `Furniture ID`, `Quantity`, `Price`,  `Sub-total` ) VALUES ('" + InfoStorage.infoSet.maxId + "','"+lblId.Text+"','"+tbxQuantity.Text+"','"+tbxPrice.Text+ "','" + tbxSubtotal.Text + "')", "Saved");
            this.Close();
            Form2 back = new Form2();
            back.Show();
        }
    }
}
