﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalProject
{
    public partial class SOFA : Form
    {
        public SOFA()
        {
            InitializeComponent();
        }

        private void btnSback_Click(object sender, EventArgs e)
        {
            this.Close();
           Form2 back = new Form2();
            back.Show();
        }

        private void btnPurchasesofa_Click(object sender, EventArgs e)
        {
            this.Hide();
            PURCHASE_FORM form = new PURCHASE_FORM();
            this.Hide();
            form.Show();
        }

        private void SOFA_Load(object sender, EventArgs e)
        {
            InfoDB.dgvViewing("SELECT * FROM `furniture_available` WHERE `Category ID`=1", dgvSofa);
        }

        private void dgvSofa_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            InfoStorage.infoSet.furnitureId = int.Parse(dgvSofa.Rows[e.RowIndex].Cells[0].Value.ToString());
            tbxSofaname.Text = (dgvSofa .Rows[e.RowIndex].Cells[2].Value.ToString());
        }

        private void btnClearsofa_Click(object sender, EventArgs e)
        {
            tbxSofaname.Text = "";
        }

        private void btnSearchsofa_Click(object sender, EventArgs e)
        {
            InfoDB.dgvViewing("SELECT * FROM `furniture_available` where Name like '%" + tbxSearchsofa.Text + "%'", dgvSofa);
        }
    }
}
