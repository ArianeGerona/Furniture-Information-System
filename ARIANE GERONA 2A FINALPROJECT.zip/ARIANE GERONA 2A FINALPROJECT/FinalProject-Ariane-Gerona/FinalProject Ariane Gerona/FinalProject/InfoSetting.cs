﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalProject
{
    class InfoSetting
    {
        public int Account_Id { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public int maxId { get; set; }
        public int furnitureId { get; set; }
    

    }
}