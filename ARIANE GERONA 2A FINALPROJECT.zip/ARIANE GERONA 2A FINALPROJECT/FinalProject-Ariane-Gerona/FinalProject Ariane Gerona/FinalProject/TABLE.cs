﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalProject
{
    public partial class TABLE : Form
    {
        public TABLE()
        {
            InitializeComponent();
        }

        private void btnTback_Click(object sender, EventArgs e)
        {
            this.Close();
            Form2 back = new Form2();
            back.Show();
        }

        private void btnPurchasetable_Click(object sender, EventArgs e)
        {
            this.Hide();
            PURCHASE_FORM form = new PURCHASE_FORM();
            this.Hide();
            form.Show();
        }

        private void TABLE_Load(object sender, EventArgs e)
        {
            InfoDB.dgvViewing("SELECT * FROM `furniture_available` WHERE `Category ID`=4", dgvTable);
        }

        private void dgvTable_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            InfoStorage.infoSet.furnitureId = int.Parse(dgvTable.Rows[e.RowIndex].Cells[0].Value.ToString());
            tbxTable.Text = (dgvTable.Rows[e.RowIndex].Cells[2].Value.ToString());
        }

        private void btnCleartable_Click(object sender, EventArgs e)
        {
            tbxTable.Text = "";
        }

        private void btnSearchtable_Click(object sender, EventArgs e)
        {
            InfoDB.dgvViewing("SELECT * FROM `furniture_available` where Name like '%" + tbxSearchtable.Text + "%'", dgvTable);
        }
    }
    
}
